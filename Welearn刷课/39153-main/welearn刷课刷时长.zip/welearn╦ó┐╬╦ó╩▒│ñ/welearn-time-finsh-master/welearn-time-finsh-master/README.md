# WelearnTimeFinsh
WeLearn刷学习时长

## 简介
* 输入账号密码一键学习
* 可以自行选择课程
* 多线程学习，同时学习整个单元
* 可以指定时间或设置随机时间
* 获取cookies教程---->[welearn获取cookis方法](https://v.youku.com/v_show/id_XNTkwNTQwOTc4MA==.html)

## 更新日志

### `v0.5dev`
* 登陆模块没时间修复了, 增加了cookies登陆方式

### `v0.4dev`
* 修复了登陆模块的问题


### `v0.3dev`

* 修复welearn更新后链接错误
* 修复了逻辑错误bug

### `v0.2dev`

* 支持学习指定单元了
* 修复没有记录错误的bug

### `v0.1dev`

* 敲出首个版本的代码
